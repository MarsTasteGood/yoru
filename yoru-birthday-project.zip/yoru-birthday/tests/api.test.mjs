import test from 'node:test';
import assert from 'node:assert/strict';
import { handleApi, birthdayMidnight } from '../server/api.js';
import { openDatabase } from '../server/sqlite.mjs';

const before = Date.parse('2026-11-13T14:59:59.999Z');
const midnight = Date.parse('2026-11-13T15:00:00.000Z');
const valid = { name: 'まつり', date: '2026-11-14', timezone: 'Asia/Tokyo', theme: 'lilac', note: 'ひとこと、待ってるね。' };
function setup(t) {
  const DB = openDatabase();
  t.after(() => DB.close());
  return async (method, pathname, body, now = before, extraHeaders = {}) => {
    const response = await handleApi(new Request('http://localhost' + pathname, { method, headers: { 'Content-Type': 'application/json', ...extraHeaders }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) }), { DB }, now);
    return { status: response.status, data: await response.json() };
  };
}

test('midnight is resolved in the birthday board timezone, including DST and fractional offsets', () => {
  assert.equal(birthdayMidnight('2026-11-14', 'Asia/Tokyo'), midnight);
  assert.equal(birthdayMidnight('2026-03-08', 'America/New_York'), Date.parse('2026-03-08T05:00:00Z'));
  assert.equal(birthdayMidnight('2026-11-01', 'America/New_York'), Date.parse('2026-11-01T04:00:00Z'));
  assert.equal(birthdayMidnight('2026-11-14', 'Asia/Kathmandu'), Date.parse('2026-11-13T18:15:00Z'));
  assert.equal(birthdayMidnight('2026-11-14', 'Etc/GMT+5'), Date.parse('2026-11-14T05:00:00Z'));
  assert.throws(() => birthdayMidnight('2011-12-30', 'Pacific/Apia'));
});

test('messages are absent before midnight, unlock exactly at midnight, and persist afterward', async t => {
  const call = setup(t);
  const created = await call('POST', '/api/boards', valid);
  assert.equal(created.status, 201);
  assert.equal(created.data.board.unlocked, false);
  assert.equal(created.data.board.unlockAt, midnight);
  assert.match(created.data.ownerToken, /^[a-f0-9]{64}$/);
  assert.equal(created.data.board.ownerToken, undefined);
  assert.equal(created.data.board.owner_hash, undefined);
  const id = created.data.board.id;
  const sent = await call('POST', `/api/boards/${id}/gifts`, { sender: 'ゆい', message: '秘密のおめでとう！', style: 'coral', idempotencyKey: 'one-gift-request-001' });
  assert.equal(sent.status, 201);
  assert.equal('message' in sent.data.gift, false);
  const sealed = await call('GET', `/api/boards/${id}`);
  assert.equal(sealed.data.board.gifts.length, 1);
  assert.equal(sealed.data.board.gifts[0].sender, 'ゆい');
  assert.equal('message' in sealed.data.board.gifts[0], false);
  assert.equal(JSON.stringify(sealed.data).includes('秘密'), false);
  const opened = await call('GET', `/api/boards/${id}`, undefined, midnight);
  assert.equal(opened.data.board.unlocked, true);
  assert.equal(opened.data.board.gifts[0].message, '秘密のおめでとう！');
  const archived = await call('GET', `/api/boards/${id}`, undefined, Date.parse('2029-11-14T00:00:00Z'));
  assert.equal(archived.data.board.gifts[0].message, '秘密のおめでとう！');
});

test('lookup requires exact owner capability and still does not reveal locked messages', async t => {
  const call = setup(t);
  const { data: created } = await call('POST', '/api/boards', valid);
  await call('POST', `/api/boards/${created.board.id}/gifts`, { sender: 'ともだち', message: 'これはまだ秘密', style: 'mint', idempotencyKey: 'lookup-secret-001' });
  const bad = await call('POST', '/api/boards/lookup', { boards: [{ id: created.board.id, ownerToken: 'a'.repeat(64) }] });
  assert.deepEqual(bad.data.boards, []);
  const good = await call('POST', '/api/boards/lookup', { boards: [{ id: created.board.id, ownerToken: created.ownerToken }, { id: created.board.id, ownerToken: created.ownerToken }] });
  assert.equal(good.data.boards.length, 1);
  assert.equal('message' in good.data.boards[0].gifts[0], false);
  assert.equal(JSON.stringify(good.data).includes(created.ownerToken), false);
});

test('duplicate submission retry creates one gift; the original is never overwritten', async t => {
  const call = setup(t);
  const { data } = await call('POST', '/api/boards', valid);
  const gift = { sender: 'ゆい', message: 'おめでとう', style: 'blue', idempotencyKey: 'retry-same-gift-001' };
  const first = await call('POST', `/api/boards/${data.board.id}/gifts`, gift);
  const retry = await call('POST', `/api/boards/${data.board.id}/gifts`, { ...gift, message: 'changed' });
  assert.equal(first.data.gift.id, retry.data.gift.id);
  const board = await call('GET', `/api/boards/${data.board.id}`, undefined, midnight);
  assert.equal(board.data.board.gifts.length, 1);
  assert.equal(board.data.board.gifts[0].message, 'おめでとう');
});

test('invalid dates, timezone, fields, body and foreign origins are rejected', async t => {
  const call = setup(t);
  for (const changes of [{ date: '2026-02-30' }, { date: '2025-02-29' }, { date: '2026-2-01' }, { timezone: 'Mars/Olympus' }, { name: '' }, { name: 'x'.repeat(25) }, { note: 'x'.repeat(121) }, { theme: 'bad' }]) {
    const result = await call('POST', '/api/boards', { ...valid, ...changes });
    assert.equal(result.status, 400, JSON.stringify(changes));
  }
  assert.equal((await call('POST', '/api/boards', valid, before, { Origin: 'https://unrelated.example' })).status, 403);
  assert.equal((await call('POST', '/api/boards', valid, before, { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await call('GET', '/api/boards/unknown')).status, 404);
  assert.equal((await call('POST', '/api/boards/lookup', { boards: 'bad' })).status, 400);
});

test('100 gift limit is enforced without blocking an idempotent retry', async t => {
  const call = setup(t);
  const { data } = await call('POST', '/api/boards', valid);
  for (let i = 0; i < 100; i++) {
    assert.equal((await call('POST', `/api/boards/${data.board.id}/gifts`, { sender: '友だち', message: `メッセージ ${i}`, style: 'butter', idempotencyKey: `count-test-gift-${String(i).padStart(4, '0')}` })).status, 201);
  }
  const tooMany = await call('POST', `/api/boards/${data.board.id}/gifts`, { sender: '友だち', message: '101件目', style: 'butter', idempotencyKey: 'count-test-gift-0100' });
  assert.equal(tooMany.status, 409);
  assert.equal(tooMany.data.code, 'board_full');
  const retry = await call('POST', `/api/boards/${data.board.id}/gifts`, { sender: '友だち', message: 'retry', style: 'butter', idempotencyKey: 'count-test-gift-0000' });
  assert.equal(retry.status, 200);
});

test('HTML remains inert data in JSON and invalid gift inputs do not save', async t => {
  const call = setup(t);
  const { data } = await call('POST', '/api/boards', valid);
  const route = `/api/boards/${data.board.id}/gifts`;
  for (const changes of [{ sender: '' }, { message: '' }, { message: 'x'.repeat(1001) }, { style: 'bad' }, { idempotencyKey: 'short' }]) {
    assert.equal((await call('POST', route, { sender: '友だち', message: 'hello', style: 'rose', idempotencyKey: 'safe-request-0001', ...changes })).status, 400);
  }
  const unsafe = '<img src=x onerror=alert(1)>';
  assert.equal((await call('POST', route, { sender: '友だち', message: unsafe, style: 'rose', idempotencyKey: 'safe-request-0002' })).status, 201);
  const board = await call('GET', `/api/boards/${data.board.id}`, undefined, midnight);
  assert.equal(board.data.board.gifts.length, 1);
  assert.equal(board.data.board.gifts[0].message, unsafe);
});
