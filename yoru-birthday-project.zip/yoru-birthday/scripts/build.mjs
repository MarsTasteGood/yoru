import { readdir, readFile, mkdir, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8' };
const assets = {};
async function collect(dir, prefix = '') {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    const key = `${prefix}/${entry.name}`;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) await collect(file, key);
    else {
      const bytes = await readFile(file);
      assets[key] = { mime: mime[path.extname(file)] || 'application/octet-stream', base64: bytes.toString('base64') };
    }
  }
}
await collect(path.join(root, 'public'));
if (!assets['/index.html']) throw new Error('public/index.html is required before building.');
const api = await readFile(path.join(root, 'server/api.js'), 'utf8');
const manifest = JSON.parse(await readFile(path.join(root, '.openai/hosting.json'), 'utf8'));
if (!manifest.project_id || !manifest.d1) throw new Error('Hosting manifest needs project_id and d1 DB binding.');
await rm(path.join(root, 'dist'), { force: true, recursive: true });
await mkdir(path.join(root, 'dist/server'), { recursive: true });
await mkdir(path.join(root, 'dist/.openai'), { recursive: true });
const worker = `${api}\nconst ASSETS = ${JSON.stringify(assets)};
export default {
  async fetch(request, env) {
    const response = await handleApi(request, env);
    if (response) return response;
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed', {status:405});
    const pathname = new URL(request.url).pathname;
    const route = pathname === '/' || /^\\/b\\/[^/]+\\/?$/.test(pathname) || ['/memories','/archive','/create'].includes(pathname) ? '/index.html' : pathname;
    const asset = ASSETS[route];
    if (!asset) return new Response('Not found', {status:404});
    const bytes = Uint8Array.from(atob(asset.base64), c => c.charCodeAt(0));
    return new Response(request.method === 'HEAD' ? null : bytes, { headers: {'Content-Type':asset.mime,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'} });
  }
};\n`;
await writeFile(path.join(root, 'dist/server/index.js'), worker);
await writeFile(path.join(root, 'dist/.openai/hosting.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(`Built Worker with ${Object.keys(assets).length} embedded assets (${Buffer.byteLength(worker)} bytes).`);
