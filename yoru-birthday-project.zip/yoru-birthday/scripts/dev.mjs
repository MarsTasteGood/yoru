import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { handleApi } from '../server/api.js';
import { openDatabase } from '../server/sqlite.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const publicRoot = path.join(root, 'public');
await mkdir(path.join(root, '.data'), { recursive: true });
const DB = openDatabase(path.join(root, '.data', 'yoru.sqlite'));
const args = process.argv.slice(2);
const flag = args.indexOf('--port');
const port = Number(flag === -1 ? (process.env.PORT || 4173) : args[flag + 1]);
const host = process.env.HOST || '127.0.0.1';
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8' };

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || `${host}:${port}`}`);
    if (url.pathname.startsWith('/api/')) {
      let size = 0;
      const chunks = [];
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 80000) { res.writeHead(413, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: '入力が長すぎます。', code: 'too_large' })); return; }
        chunks.push(chunk);
      }
      const body = Buffer.concat(chunks);
      const request = new Request(url, { method: req.method, headers: req.headers, ...(body.length ? { body } : {}) });
      const response = await handleApi(request, { DB });
      res.writeHead(response.status, Object.fromEntries(response.headers));
      res.end(Buffer.from(await response.arrayBuffer()));
      return;
    }
    if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); res.end(); return; }
    let requested;
    try { requested = decodeURIComponent(url.pathname); } catch { res.writeHead(400); res.end(); return; }
    if (requested === '/' || /^\/b\/[^/]+\/?$/.test(requested) || ['/memories', '/archive', '/create'].includes(requested)) requested = '/index.html';
    const filename = path.resolve(publicRoot, '.' + requested);
    if (!filename.startsWith(publicRoot + path.sep) || requested.split('/').some(part => part.startsWith('.'))) { res.writeHead(404); res.end(); return; }
    try {
      const contents = await readFile(filename);
      res.writeHead(200, { 'Content-Type': mime[path.extname(filename)] || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' });
      res.end(req.method === 'HEAD' ? undefined : contents);
    } catch { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Not found'); }
  } catch (error) {
    console.error(error);
    if (!res.headersSent) res.writeHead(500);
    res.end('Server error');
  }
});
server.listen(port, host, () => console.log(`yoru preview: http://${host}:${port}\nBoards are saved in .data/yoru.sqlite`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => { DB.close(); process.exit(0); }));
