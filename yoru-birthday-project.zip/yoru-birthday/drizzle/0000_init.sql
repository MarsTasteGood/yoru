CREATE TABLE boards (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  birthday TEXT NOT NULL,
  timezone TEXT NOT NULL,
  theme TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  unlock_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  owner_hash TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE gifts (
  id TEXT PRIMARY KEY NOT NULL,
  board_id TEXT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
  sender TEXT NOT NULL,
  message TEXT NOT NULL,
  style TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  idempotency_key TEXT NOT NULL,
  UNIQUE(board_id, idempotency_key)
);
--> statement-breakpoint
CREATE INDEX gifts_board_created ON gifts(board_id, created_at);
