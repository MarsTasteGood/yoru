const THEMES = new Set(['lilac', 'peach', 'mint']);
const STYLES = new Set(['lilac', 'coral', 'mint', 'butter', 'blue', 'rose']);
const ID = /^[a-f0-9]{32}$/;
const MAX_GIFTS = 100;

class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
  } });
}

function textField(value, label, max, optional = false) {
  if (typeof value !== 'string') {
    if (optional && value == null) return '';
    throw new ApiError(400, 'invalid_input', `${label}を入力してください。`);
  }
  const clean = value.trim().replace(/\r\n?/g, '\n');
  if ((!optional && !clean) || clean.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(clean)) {
    throw new ApiError(400, 'invalid_input', `${label}は${max}文字以内で入力してください。`);
  }
  return clean;
}

async function bodyOf(request) {
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) {
    throw new ApiError(415, 'invalid_content_type', '送信形式を確認してください。');
  }
  if (Number(request.headers.get('content-length')) > 20000) throw new ApiError(413, 'too_large', '入力が長すぎます。');
  const raw = await request.text();
  if (raw.length > 20000) throw new ApiError(413, 'too_large', '入力が長すぎます。');
  try {
    const value = JSON.parse(raw);
    if (!value || Array.isArray(value) || typeof value !== 'object') throw new Error();
    return value;
  } catch { throw new ApiError(400, 'invalid_json', '入力内容を確認してください。'); }
}

function id() { return crypto.randomUUID().replaceAll('-', ''); }
async function hash(value) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)))].map(x => x.toString(16).padStart(2, '0')).join('');
}

// Resolve midnight in the board's chosen IANA zone, independent of viewer/host time.
export function birthdayMidnight(date, timezone) {
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new ApiError(400, 'invalid_date', '誕生日を選んでください。');
  const [year, month, day] = date.split('-').map(Number);
  const target = Date.UTC(year, month - 1, day);
  if (year < 1900 || year > 2200 || new Date(target).toISOString().slice(0, 10) !== date) {
    throw new ApiError(400, 'invalid_date', '正しい日付を選んでください。');
  }
  let formatter;
  try {
    if (typeof timezone !== 'string' || timezone.length > 80 || !/^[A-Za-z0-9_+\-/]+$/.test(timezone)) throw new Error();
    formatter = new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
  } catch { throw new ApiError(400, 'invalid_timezone', 'タイムゾーンを選び直してください。'); }
  const localStamp = time => {
    const p = Object.fromEntries(formatter.formatToParts(time).map(part => [part.type, part.value]));
    return Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second));
  };
  let guess = target;
  for (let i = 0; i < 5; i++) {
    const offset = target - localStamp(guess);
    if (!offset) {
      // Some regions repeat midnight. Unlock at the first occurrence.
      for (const delta of [7200000, 3600000, 1800000]) if (localStamp(guess - delta) === target) return guess - delta;
      return guess;
    }
    guess += offset;
  }
  throw new ApiError(400, 'unavailable_midnight', 'この地域では指定日の0時がありません。別の日付か地域を選んでください。');
}

async function boardById(env, boardId) {
  if (!ID.test(boardId)) throw new ApiError(404, 'not_found', 'ボードが見つかりません。リンクを確認してください。');
  const row = await env.DB.prepare('SELECT * FROM boards WHERE id = ?').bind(boardId).first();
  if (!row) throw new ApiError(404, 'not_found', 'ボードが見つかりません。リンクを確認してください。');
  return row;
}

async function publicBoard(env, row, now) {
  const unlocked = now >= row.unlock_at;
  // Never even select message bodies before unlock; no client-side hiding.
  const fields = unlocked ? 'id, sender, style, created_at, message' : 'id, sender, style, created_at';
  const result = await env.DB.prepare(`SELECT ${fields} FROM gifts WHERE board_id = ? ORDER BY created_at ASC, rowid ASC`).bind(row.id).all();
  const gifts = result.results.map(gift => ({ id: gift.id, sender: gift.sender, style: gift.style, createdAt: gift.created_at, ...(unlocked ? { message: gift.message } : {}) }));
  return { id: row.id, name: row.name, date: row.birthday, timezone: row.timezone, theme: row.theme, note: row.note, unlockAt: row.unlock_at, createdAt: row.created_at, unlocked, gifts };
}

export async function handleApi(request, env, now = Date.now()) {
  const url = new URL(request.url);
  if (!url.pathname.startsWith('/api/')) return null;
  try {
    if (!env?.DB) throw new ApiError(503, 'storage_unavailable', 'ただいま準備中です。少し待ってから試してください。');
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      const origin = request.headers.get('origin');
      if (origin && origin !== url.origin) throw new ApiError(403, 'origin_mismatch', 'このページからもう一度送信してください。');
    }
    if (request.method === 'POST' && url.pathname === '/api/boards') {
      const body = await bodyOf(request);
      const name = textField(body.name, '名前', 24);
      const note = textField(body.note, 'ひとこと', 120, true);
      if (!THEMES.has(body.theme)) throw new ApiError(400, 'invalid_theme', 'ボードの色を選んでください。');
      const unlockAt = birthdayMidnight(body.date, body.timezone);
      const boardId = id();
      const ownerToken = id() + id();
      await env.DB.prepare('INSERT INTO boards (id,name,birthday,timezone,theme,note,unlock_at,created_at,owner_hash) VALUES (?,?,?,?,?,?,?,?,?)').bind(boardId, name, body.date, body.timezone, body.theme, note, unlockAt, now, await hash(ownerToken)).run();
      return json({ board: await publicBoard(env, await boardById(env, boardId), now), ownerToken, serverNow: now }, 201);
    }
    if (request.method === 'POST' && url.pathname === '/api/boards/lookup') {
      const body = await bodyOf(request);
      if (!Array.isArray(body.boards) || body.boards.length > 100) throw new ApiError(400, 'invalid_input', 'ボードの一覧を確認してください。');
      const boards = [];
      const seen = new Set();
      for (const item of body.boards) {
        if (!item || !ID.test(item.id) || typeof item.ownerToken !== 'string' || !/^[a-f0-9]{64}$/.test(item.ownerToken) || seen.has(item.id)) continue;
        seen.add(item.id);
        const row = await env.DB.prepare('SELECT * FROM boards WHERE id = ? AND owner_hash = ?').bind(item.id, await hash(item.ownerToken)).first();
        if (row) boards.push(await publicBoard(env, row, now));
      }
      return json({ boards: boards.sort((a, b) => b.unlockAt - a.unlockAt), serverNow: now });
    }
    const match = url.pathname.match(/^\/api\/boards\/([^/]+)(\/gifts)?$/);
    if (match && request.method === 'GET' && !match[2]) {
      return json({ board: await publicBoard(env, await boardById(env, match[1]), now), serverNow: now });
    }
    if (match && request.method === 'POST' && match[2]) {
      const board = await boardById(env, match[1]);
      const body = await bodyOf(request);
      const sender = textField(body.sender, '名前', 24);
      const message = textField(body.message, 'メッセージ', 1000);
      if (!STYLES.has(body.style)) throw new ApiError(400, 'invalid_style', 'プレゼントを選んでください。');
      if (typeof body.idempotencyKey !== 'string' || !/^[a-zA-Z0-9_-]{16,80}$/.test(body.idempotencyKey)) throw new ApiError(400, 'invalid_key', 'もう一度送信してください。');
      const previous = await env.DB.prepare('SELECT id,sender,style,created_at FROM gifts WHERE board_id = ? AND idempotency_key = ?').bind(board.id, body.idempotencyKey).first();
      if (previous) return json({ gift: { id: previous.id, sender: previous.sender, style: previous.style, createdAt: previous.created_at }, serverNow: now });
      const giftId = id();
      await env.DB.prepare('INSERT OR IGNORE INTO gifts (id,board_id,sender,message,style,created_at,idempotency_key) SELECT ?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM gifts WHERE board_id = ?) < ?').bind(giftId, board.id, sender, message, body.style, now, body.idempotencyKey, board.id, MAX_GIFTS).run();
      const saved = await env.DB.prepare('SELECT id,sender,style,created_at FROM gifts WHERE board_id = ? AND idempotency_key = ?').bind(board.id, body.idempotencyKey).first();
      if (!saved) throw new ApiError(409, 'board_full', 'このボードはプレゼントでいっぱいです。');
      return json({ gift: { id: saved.id, sender: saved.sender, style: saved.style, createdAt: saved.created_at }, serverNow: now }, 201);
    }
    return json({ error: 'ページが見つかりません。', code: 'not_found' }, 404);
  } catch (error) {
    if (error instanceof ApiError) return json({ error: error.message, code: error.code }, error.status);
    console.error('API operation failed', error?.message || 'Unknown error');
    return json({ error: '保存できませんでした。少し待ってから、もう一度試してください。', code: 'server_error' }, 500);
  }
}
